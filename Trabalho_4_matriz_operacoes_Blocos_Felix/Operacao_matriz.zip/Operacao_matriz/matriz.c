#include "matriz.h"
#include <time.h>

// %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% MATRIZ %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
// %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
int gerar_matriz(int **matriz, int linha, int coluna, int valor){
  srand(time(0));
  for (int i=0; i < linha; i++)
	  for (int j=0; j < coluna; j++)
			if (valor == -9999)
				matriz[i][j] = rand() % 10;
			else
				matriz[i][j] = valor;
	return 0;
}

// %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
int zerar_matriz (int **matriz, int linha, int coluna){
	return gerar_matriz(matriz,linha,coluna,0);
}

// %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
int imprimir_matriz (int **matriz, int linha, int coluna){
	for (int j =0; j < coluna; j++)
		printf("\t(%d)", j);
	printf("\n");
	for (int i=0; i < linha; i++) {
		printf("(%d)", i);
	  for (int j=0; j < coluna; j++){
			printf("\t%d", matriz[i][j]);
		}
		printf("\n");
	}
	return 0;
}

// %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
int comparar_matriz (int **matriza, int **matrizb, int linha, int coluna){
	for (int j =0; j < coluna; j++)
	for (int i=0; i < linha; i++) {
	  for (int j=0; j < coluna; j++){
			if (matriza[i][j] != matrizb[i][j]) {
				printf("O elemento [%d,%d] é diferente nas matrizes analisadas!", i,j);
				return 1;
			}
		}

	}
	printf("VERIFICADO: Matrizes identicas\n");
	return 0;
}


// %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
int **liberar_matriz (int **matriz, int linha, int coluna) {
  for (int i =0; i < linha; i++)
			free(matriz[i]);
	free(matriz);
	return NULL;
}

// %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
int **alocar_matriz (int linha, int coluna) {
  int **nova_a = NULL;

	nova_a = (int **) malloc(linha*sizeof(int *));
	if (!nova_a) {
		printf("ERROR: Out of memory\n");
		return NULL;
	}

  for (int i =0; i < linha; i++) {
			nova_a[i] = (int *) malloc(sizeof(int)*coluna);
			if (!nova_a) {
				printf("ERROR: Out of memory\n");
				return NULL;
			}
	}
	return nova_a;
}

// //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
// int gerar_submatriz (int **mat_origem, matriz_bloco_t *submatriz, bloco_t *bloco) {
//         #TODO
//   return 0;
// }
//
// // %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
// int imprimir_submatriz (matriz_bloco_t *submatriz){
//         #TODO
// 	return 0;
//}

// %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
// int imprimir_bloco (matriz_bloco_t *submatriz) {
//         #TODO
// 	return 0;
// }

// %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
// orientacao, 1 corte horizontal, 0 para corte vertical
matriz_bloco_t **particionar_matriz (int **matriz, int mat_lin, int mat_col, int orientacao, int divisor) {
  matriz_bloco_t **submatriz[divisor-1];
  int size_lin= (mat_lin/divisor);
  int size_col= (mat_col/divisor);
  if (orientacao == 1) {
    //(*submatriz)->bloco->lin_inicio=0;
    (*submatriz)=constroi_submatrizv2(size_lin, mat_col, divisor);
    printf("deu certo constroi_submatrizv2\n" );
    for (int i=0; i < divisor; i ++)
      for (int j=0; j < size_lin; j ++)
        for (int k=0; k < mat_col; k ++){
          (*submatriz[i])->matriz[j][k] = matriz[j+(i*size_lin)][k];
        }
  }
  else {
    (*submatriz)=constroi_submatrizv2(mat_lin, size_col, divisor);
    for (int i=0; i < divisor; i++)
      for (int j=0; j < mat_lin; j++)
        for (int k=0; k < size_col; k++)
        (*submatriz[i])->matriz[j][k] = matriz[j][k+(i*size_col)];
  }
  return *submatriz;
}



// %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
matriz_bloco_t **constroi_submatrizv2 (int mat_lin, int mat_col, int divisor) {
  matriz_bloco_t **vet_subc;
  vet_subc =  malloc(divisor*sizeof(int *));
  // int vet_subc[0]->matriz[mat_lin][mat_col];
  //memset( (*vet_subc[0])->matriz, 0, mat_lin*mat_col*sizeof(int) );
for (int i=0; i < divisor; i++){
  (*vet_subc[i]).matriz=calloc(mat_lin,sizeof(int*));
  for(int j=0; j < mat_lin; j++){
    (*vet_subc[i]).matriz[j]=calloc(mat_col,sizeof(int*));
  }
}

  //(*vet_subc[1])->matriz= alocar_matriz (mat_lin, mat_col);
  if (!(*vet_subc[0]).matriz) {
    printf("ERROR: Out of memory\n");
}
  //vet_subc = (matriz_bloco_t **) malloc(divisor*sizeof(int *));

  //printf("%d\n", (*vet_subc[0]).matriz[0][0] );


  // for (int i = 0; i < divisor; i++) {
  //   (*vet_subc[i])->bloco->lin_inicio=(int) malloc(sizeof(int *));
  //   (*vet_subc[i])->bloco->lin_fim=(int) malloc(sizeof(int *));
  //   (*vet_subc[i])->bloco->col_inicio=(int) malloc(sizeof(int *));
  //   (*vet_subc[i])->bloco->lin_fim=(int) malloc(sizeof(int *));
  //   printf("vai se fuder\n");
  //   //(*vet_subc[i])->matriz=NULL;
  //
  //   (*vet_subc[i])->matriz = alocar_matriz(mat_lin, mat_col);
  // }

  return vet_subc;

}

// %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
matriz_bloco_t **liberar_submatriz (matriz_bloco_t **submatriz) {

  free(submatriz);
  // for (int i =0; i < linha; i++)
  //   free(matriz[i]);
	// free(matriz);
  return NULL;
}
